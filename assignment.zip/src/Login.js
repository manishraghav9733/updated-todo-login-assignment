import React,{useState} from 'react'


const Login = () => {

    const [isLoged,setIsLoged] = useState(false);
    const [userName,setUserName] = useState("");
    const [password,setPassword] = useState("");


    const handleLogin = () => {
        if(userName === "manish" && password=== "1234" )
        {

        setIsLoged(true);   
        }else{
            alert("please enter details");
        }
    }

    const onUserNameChange = e =>{
        //console.log(e.target.value);
        setUserName(e.target.value);
    }

    const onPassChange = e =>{
        //console.log(e.target.value);
        setPassword(e.target.value);
    }
    

        return (
            <div>
                {
                    isLoged === true ? document.location.assign("/profile") : null
                }
                <div className="container" >
                    <div className="signup" >
                        <div className="row" id="divstyle1" >
                            <div className="col-lg-6 col-md-12 col-sm-12 align-middle" id="divstyle2">
                                <h3 >New To Our Shop</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua</p>
                                <a href="#" className="btn btn-lg in" id="divstyle4">Logout </a>
                            </div>
                            <div className="col-lg-6 col-md-12 col-sm-12 text-center" >
                                <h3>Welcome Again!</h3>
                                <h3>Please Sign In Now </h3>
                            
                                <div className="form-group">
                                  <input type="text" className="form-control"    placeholder="Username" onChange={ onUserNameChange}  />
                                </div>
                                <div className="form-group">
                                  <input type="password" className="form-control"  placeholder="Password"  onChange={onPassChange} />
                                </div>
  
    
                                  <button
                                   onClick={handleLogin} 
                                  type="submit" 
                                  id="fbtn" 
                                  className="btn btn-block mx-auto" 
                                  >
                                      login
                                  </button>
                            
    
    
            </div>
        </div>
    </div>
</div>
            </div>
        )
}   

export default Login;